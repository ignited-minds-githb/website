/**
 * MENTORS DATA FILE
 * -----------------
 * To add a new mentor, simply copy the template below and fill in the details.
 * Place mentor photos in: images/mentors/
 *
 * Template:
 * {
 *   name: "Mentor Name",
 *   role: "Role / Designation",
 *   photo: "images/mentors/filename.jpg",
 *   bio: "Short bio about the mentor.",
 *   linkedin: "https://linkedin.com/in/username",  // optional
 *   expertise: ["Skill 1", "Skill 2"]
 * }
 */

const mentorsData = [
  {
    name: "Dr. Sanjay Patidar",
    role: "Professor at DTU",
    photo: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=400&h=400&fit=crop",
    bio: "Initiator of the Ignited Minds vision and a professor in Computer Science and Software Engineering at DTU. Dedicated to inspiring and guiding students to achieve their highest potential.",
    linkedin: "#",
    expertise: ["Visionary", "Computer Science", "Software Engineering"]
  },
  {
    name: "Ashish Patidar",
    role: "Software Engineer at Optum",
    photo: "https://images.unsplash.com/photo-1501854140801-50d01698950b?w=400&h=400&fit=crop",
    bio: "One of the mentors for technology and engineering. Passionate about helping students explore and excel in the world of technology.",
    linkedin: "#",
    expertise: ["Technology", "Engineering", "Mentorship"]
  },
  {
    name: "Jyoti Patidar",
    role: "PhD Scholar in Software Engineering",
    photo: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=400&h=400&fit=crop",
    bio: "Pursuing PhD in Software Engineering and one of the important mentors of Ignited Minds. Passionate about research and guiding students in their academic and professional journeys.",
    linkedin: "#",
    expertise: ["Software Engineering", "Research", "Mentorship"]
  },
  {
    name: "You?",
    role: "Become a Mentor!",
    photo: "https://images.unsplash.com/photo-1465101046530-73398c7f28ca?w=400&h=400&fit=crop",
    bio: "We are always looking for passionate mentors who truly want to help students. If you want to join us as a mentor, contact us — you are most welcome!",
    linkedin: "mailto:ignitedminds@example.com",
    expertise: ["Mentorship", "Inspiration", "Support"]
  }
];
