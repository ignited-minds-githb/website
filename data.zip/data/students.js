/**
 * STUDENTS DATA FILE
 * ------------------
 * To add a new student success story, copy the template below and fill in details.
 * Place student photos in: images/students/
 *
 * Template:
 * {
 *   name: "Student Name",
 *   photo: "images/students/filename.jpg",
 *   achievement: "Short achievement title",
 *   story: "Their inspiring journey...",
 *   year: "2026",
 *   tags: ["Tag1", "Tag2"]
 * }
 */

const studentsData = [
  {
    name: "Amit Kumar",
    photo: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=400&h=400&fit=crop",
    achievement: "Cleared UPSC Civil Services",
    story: "Coming from a small village with limited resources, Amit struggled to find proper guidance for UPSC preparation. Ignited Minds mentors helped him build a structured study plan, provided free study material, and conducted regular mock interviews. After two years of dedicated preparation, Amit cleared the UPSC exam with an outstanding rank. Today he serves as an IAS officer, giving back to his community.",
    year: "2025",
    tags: ["UPSC", "Civil Services", "Government"]
  },
  {
    name: "Kavita Meena",
    photo: "https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=400&h=400&fit=crop",
    achievement: "Got into IIT Bombay – B.Tech CSE",
    story: "Kavita was a bright student from a government school who dreamed of studying at IIT. With no access to expensive coaching, she connected with Ignited Minds. Our mentors provided her free online coaching, doubt-clearing sessions, and constant motivation. She secured AIR 342 in JEE Advanced and is now pursuing Computer Science at IIT Bombay.",
    year: "2025",
    tags: ["JEE", "IIT", "Engineering"]
  },
  {
    name: "Ravi Patel",
    photo: "https://images.unsplash.com/photo-1500964757637-9867a8c1b0c3?w=400&h=400&fit=crop",
    achievement: "Full Scholarship to Study Abroad",
    story: "Ravi always dreamed of studying abroad but his family couldn't afford the fees. Ignited Minds mentors guided him through the scholarship application process, helped him craft compelling essays, and prepared him for interviews. He received a full scholarship to pursue his Masters at a top European university.",
    year: "2024",
    tags: ["Scholarship", "Study Abroad", "Masters"]
  },
  {
    name: "Sunita Yadav",
    photo: "https://images.unsplash.com/photo-1490750967868-88aa4f44baee?w=400&h=400&fit=crop",
    achievement: "Became a Software Engineer at Google",
    story: "Sunita, a first-generation learner, had passion for coding but no direction. Through Ignited Minds' tech mentorship program, she learned data structures, algorithms, and system design. After months of rigorous practice and guidance, she cracked the Google interview and is now working as a Software Engineer in Bangalore.",
    year: "2024",
    tags: ["Technology", "Software", "Google"]
  },
  {
    name: "Deepak Singh",
    photo: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=400&h=400&fit=crop",
    achievement: "NEET Topper – MBBS at AIIMS Delhi",
    story: "Deepak lost his father at a young age and nearly gave up on his dream of becoming a doctor. Ignited Minds not only provided him with academic mentoring but also emotional support during tough times. He scored 705/720 in NEET and is now studying MBBS at AIIMS Delhi, determined to serve rural communities as a doctor.",
    year: "2025",
    tags: ["NEET", "Medical", "AIIMS"]
  },
  {
    name: "Pooja Kumari",
    photo: "https://images.unsplash.com/photo-1501854140801-50d01698950b?w=400&h=400&fit=crop",
    achievement: "State Board Topper – Class 12",
    story: "From a remote tribal area, Pooja had to walk 5 km daily to reach school. Despite all odds, with guidance from Ignited Minds mentors through online sessions, she topped the state board exams in Class 12 with 98.4%. Her story has inspired hundreds of students in her district to pursue education seriously.",
    year: "2026",
    tags: ["Board Exams", "Academics", "Inspiration"]
  }
];

