/**
 * GALLERY DATA FILE
 * -----------------
 * To add new gallery items, copy the template below.
 * Place gallery images in: images/gallery/
 * Supports both images and videos (YouTube embed links).
 *
 * Template:
 * {
 *   type: "image",  // "image" or "video"
 *   src: "images/gallery/filename.jpg",  // or YouTube embed URL for video
 *   caption: "Description of the photo/video",
 *   category: "events"  // "events", "sessions", "celebrations", "other"
 * }
 */

const galleryData = [
  {
    type: "image",
    src: "https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=600&h=400&fit=crop",
    caption: "Mentorship session with students",
    category: "sessions"
  },
  {
    type: "image",
    src: "https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=600&h=400&fit=crop",
    caption: "Group study and doubt clearing",
    category: "sessions"
  },
  {
    type: "image",
    src: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&h=400&fit=crop",
    caption: "Annual Ignited Minds Meet 2025",
    category: "events"
  },
  {
    type: "image",
    src: "https://images.unsplash.com/photo-1511578314322-379afb476865?w=600&h=400&fit=crop",
    caption: "Career guidance workshop",
    category: "events"
  },
  {
    type: "image",
    src: "https://images.unsplash.com/photo-1529070538774-1843cb3265df?w=600&h=400&fit=crop",
    caption: "Students celebrating their results",
    category: "celebrations"
  },
  {
    type: "image",
    src: "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?w=600&h=400&fit=crop",
    caption: "Graduation ceremony",
    category: "celebrations"
  },
  {
    type: "video",
    src: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    caption: "Student testimonial – Amit's Journey",
    category: "sessions"
  },
  {
    type: "image",
    src: "https://images.unsplash.com/photo-1577896851231-70ef18881754?w=600&h=400&fit=crop",
    caption: "Online mentoring session",
    category: "sessions"
  }
];

